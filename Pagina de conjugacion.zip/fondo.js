function cambia(x) {
	var body = document.getElementById('body');
	body.style.backgroundColor = x.value
}